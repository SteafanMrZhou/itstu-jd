package com.itstu.jd.common;

public class BusinessCode {

    public static final String CURRENT_USER = "currentUser";

    /**
     * 用户注册类型封装
     *
     */
    public interface userRegisterType{
        int USER_EMAIL_REGISTER = 0;
        int USER_NAME_REGISTER = 1;
        int USER_PHONE_REGISTER = 2;
    }
}
