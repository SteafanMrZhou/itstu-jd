package com.itstu.jd.common;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.databind.annotation.JsonSerialize;

import java.io.Serializable;

@JsonSerialize
@JsonInclude(JsonInclude.Include.NON_NULL)
public class Response<T> implements Serializable {
    private int code;
    private String msg;
    private T data;

    public int getCode(){
        return code;
    }
    public String getMsg(){
        return msg;
    }
    public T getData(){
        return data;
    }

    private Response(int code, String msg){
        this.code = code;
        this.msg = msg;
    }

    private Response(int code, T data) {
        this.code = code;
        this.data = data;
    }

    private Response(int code, String msg, T data) {
        this.code = code;
        this.msg = msg;
        this.data = data;
    }

    private Response(String msg, T data) {
        this.msg = msg;
        this.data = data;
    }

    public static <T> Response successResponse(){
        return new Response(Const.SUCCESS.getStatus(), Const.SUCCESS.getDesc());
    }
    public static <T> Response successResponse(String msg){
        return new Response(Const.SUCCESS.getStatus(), msg);
    }
    public static <T> Response successResponse(int code, String msg){
        return new Response(code, msg);
    }
    public static <T> Response successResponse(T data){
        return new Response(Const.SUCCESS.getStatus(), Const.SUCCESS.getDesc(), data);
    }

    public static <T> Response errorResponse(){
        return new Response(Const.ERROR.getStatus(), Const.ERROR.getDesc());
    }
    public static <T> Response errorResponse(String errMsg) {
        return new Response(Const.ERROR.getStatus(), errMsg);
    }
    public static <T> Response errorResponse(int errCode, String errMsg) {
        return new Response(errCode, errMsg);
    }
}
