package com.itstu.jd.common;

public enum Const {

    SUCCESS(0, "SUCCESS"),
    FAILED(1, "FAILED"),
    ERROR(2, "ERROR"),
    ILLEGAL_ARGUMENT(3, "ILLEGAL_ARGUMENT"),
    NO_PERMISSION(4, "NOPERMISSION"),
    NEED_LOGIN(10, "NEED_LOGIN");


    private int status;
    private String desc;

    Const(int status, String desc){
        this.status = status;
        this.desc = desc;
    }

    public int getStatus(){
        return status;
    }

    public String getDesc(){
        return desc;
    }
}
