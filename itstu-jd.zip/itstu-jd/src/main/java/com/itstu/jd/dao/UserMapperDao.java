package com.itstu.jd.dao;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.itstu.jd.pojo.UserPojo;

public interface UserMapperDao extends BaseMapper<UserPojo> {

}
