package com.itstu.jd.service;

import com.itstu.jd.common.Response;
import com.itstu.jd.pojo.UserPojo;
import org.apache.ibatis.annotations.Param;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.multipart.MultipartFile;

import javax.servlet.http.HttpSession;
import java.io.IOException;

public interface IUserService {

    Response<UserPojo> userLogin(Integer userLoginType, @RequestBody UserPojo loginUser, HttpSession session);

    Response<String> uploadUserIcon(@Param("userIcon") MultipartFile userIcon) throws IOException;

    Response<String> userRegister(Integer userRegisterType, UserPojo userPojo, String userIconAddress);

    Response<String> resetPassword(HttpSession session, String newPass);

    Response<String> forgetResetPassword(HttpSession session, String question, String answer);

    Response<String> updateUserInfo(HttpSession session, @RequestBody UserPojo userUpdate);
}
