package com.itstu.jd.pojo;

import com.baomidou.mybatisplus.annotation.TableId;
import com.baomidou.mybatisplus.annotation.TableName;
import lombok.*;

import java.io.Serializable;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@ToString
@TableName("jd_user")
public class UserPojo implements Serializable {
    @TableId
    private Integer id;
    private String username;
    private String password;
    private String userIcon;
    private String phone;
    private String email;
    private Integer role;
    private String pasQuestion;
    private String pasAnswer;
    private String createTime;
    private String updateTime;
}
