package com.itstu.jd.controller;

import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.itstu.jd.common.Response;
import com.itstu.jd.dao.UserMapperDao;
import com.itstu.jd.pojo.UserPojo;
import com.itstu.jd.service.IUserService;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiParam;
import org.apache.ibatis.annotations.Param;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.multipart.MultipartFile;

import javax.servlet.http.HttpSession;
import java.io.IOException;
import java.util.List;

@Controller
@RequestMapping("/user/")
@Api(tags = "user")
public class UserController {

    @Autowired
    private IUserService userService;

    /**
     * 用户登录接口
     *
     * @param userLoginType
     * @param loginUser
     * @param session
     * @return
     */
    @RequestMapping(value = "user_login.do", method = RequestMethod.POST)
    @ResponseBody
    @ApiOperation(value = "用户登录接口，返回用户登录状态")
    public Response<UserPojo> userLogin(Integer userLoginType, @RequestBody UserPojo loginUser, HttpSession session){
        return userService.userLogin(userLoginType, loginUser, session);
    }

    /**
     * 用户头像上传接口
     *
     * @param userIcon 用户头像
     * @return 上传成功的用户头像地址
     * @throws IOException
     */
    @RequestMapping(value = "upload_user_icon.do", method = RequestMethod.POST)
    @ResponseBody
    @ApiOperation(value = "用户头像上传接口，返回上传成功的用户头像地址")
    public Response<String> uploadUserIcon(@Param("userIcon") MultipartFile userIcon) throws IOException{
        return userService.uploadUserIcon(userIcon);
    }

    /**
     * 用户注册接口
     *
     * @param userRegisterType 用户注册类型
     * @param userPojo 注册用户
     * @param userIconAddress 用户头像地址
     * @return 注册状态信息
     */
    @RequestMapping(value = "user_register.do", method = RequestMethod.POST)
    @ResponseBody
    @ApiOperation(value = "用户注册接口，返回注册状态信息")
    public Response<String> userRegister(Integer userRegisterType, @RequestBody UserPojo userPojo, String userIconAddress){
        return userService.userRegister(userRegisterType, userPojo, userIconAddress);
    }

    /**
     * 记住密码的修改密码接口
     *
     * @param session
     * @param newPass
     * @return
     */
    @RequestMapping(value = "reset_password.do", method = RequestMethod.POST)
    @ResponseBody
    @ApiOperation(value = "记住密码的修改密码接口，返回密码修改状态")
    public Response<String> resetPassword(HttpSession session, String newPass){
        return userService.resetPassword(session, newPass);
    }

    /**
     * 忘记密码的找回密码接口
     *
     * @param session
     * @param question
     * @param answer
     * @return
     */
    @RequestMapping(value = "forget_reset_password.do", method = RequestMethod.POST)
    @ResponseBody
    @ApiOperation(value = "忘记密码的找回密码接口，返回密码找回结果")
    public Response<String> forgetResetPassword(HttpSession session, String question, String answer){
        return userService.forgetResetPassword(session, question, answer);
    }


    /**
     * 修改个人信息接口
     *
     * @param session
     * @param userUpdate
     * @return
     */
    @RequestMapping(value = "update_user_info.do", method = RequestMethod.POST)
    @ResponseBody
    @ApiOperation(value = "修改个人信息接口，返回修改结果")
    public Response<String> updateUserInfo(HttpSession session, @RequestBody UserPojo userUpdate){
        return userService.updateUserInfo(session, userUpdate);
    }
}
