package com.itstu.jd.service.impl;

import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.itstu.jd.common.BusinessCode;
import com.itstu.jd.common.Response;
import com.itstu.jd.dao.UserMapperDao;
import com.itstu.jd.pojo.UserPojo;
import com.itstu.jd.service.IUserService;
import com.itstu.jd.utils.MD5Util;
import lombok.extern.slf4j.Slf4j;
import net.bytebuddy.description.field.FieldList;
import org.apache.commons.net.ftp.FTPClient;
import org.apache.ibatis.annotations.Param;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import org.springframework.web.HttpSessionRequiredException;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.multipart.MultipartFile;

import javax.servlet.http.HttpSession;
import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;

@Slf4j
@Service("userService")
public class UserServiceImpl implements IUserService {

    @Value("${jd-file.file-prefix}")
    private String filePrefix;
    @Value("${jd-file.file-server-host}")
    private String fileServerHost;
    @Value("${jd-file.file-server-port}")
    private String fileServerPort;
    @Value("${jd-file.file-ftp-user}")
    private String fileFtpUser;
    @Value("${jd-file.file-ftp-pass}")
    private String fileFtpPass;
    @Value("${jd-file.file-upload-path}")
    private String fileUploadPath;

    @Autowired
    private UserMapperDao userMapperDao;

    public Response<UserPojo> userLogin(Integer userLoginType, @RequestBody UserPojo loginUser, HttpSession session) {
        QueryWrapper queryWrapper = new QueryWrapper();
        UserPojo userLogin = null;
        Map<String, Object> userLoginRequireMap = new HashMap<>();
        if (userLoginType > 0) {
            switch (userLoginType) {
                case BusinessCode.userRegisterType.USER_EMAIL_REGISTER:
                    // 邮箱登录
                    queryWrapper.eq("email", loginUser.getEmail());
                    UserPojo email = userMapperDao.selectOne(queryWrapper);
                    if (null == email) {
                        return Response.errorResponse("该邮箱不存在");
                    }
                    userLoginRequireMap.put("username", loginUser.getUsername());
                    userLoginRequireMap.put("password", MD5Util.getMD5(loginUser.getPassword()));
                    queryWrapper.allEq(userLoginRequireMap);
                    userLogin = userMapperDao.selectOne(queryWrapper);
                    if (null == userLogin) {
                        return Response.errorResponse("用户密码输入错误，请检查后重试");
                    }
                    session.setAttribute(BusinessCode.CURRENT_USER, userLogin);
                    return Response.successResponse(userLogin);
                case BusinessCode.userRegisterType.USER_NAME_REGISTER:
                    // 用户名登录
                    queryWrapper.eq("username", loginUser.getUsername());
                    UserPojo username = userMapperDao.selectOne(queryWrapper);
                    if (null == username) {
                        return Response.errorResponse("该用户不存在");
                    }
                    userLoginRequireMap.put("username", loginUser.getUsername());
                    userLoginRequireMap.put("password", MD5Util.getMD5(loginUser.getPassword()));
                    queryWrapper.allEq(userLoginRequireMap);
                    userLogin = userMapperDao.selectOne(queryWrapper);
                    if (null == userLogin) {
                        return Response.errorResponse("用户密码输入错误，请检查后重试");
                    }
                    session.setAttribute(BusinessCode.CURRENT_USER, userLogin);
                    return Response.successResponse(userLogin);
                case BusinessCode.userRegisterType.USER_PHONE_REGISTER:
                    // todo 手机登录，集成手机验证码校验
                    break;
                default:
                    break;
            }
        }
        return Response.errorResponse("登录参数传递错误，请重新登录");
    }

    public Response<String> uploadUserIcon(@Param("userIcon") MultipartFile userIcon) throws IOException {
        FTPClient client = new FTPClient();
        if (userIcon.isEmpty()) {
            return Response.errorResponse("您还没有选择任何头像，请选择用户头像");
        }
        String userIconTotalName = userIcon.getOriginalFilename();
        SimpleDateFormat simpleDateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
        String currDate = simpleDateFormat.format(new Date());
        String uploadedFileName = filePrefix + currDate + userIconTotalName;
        client.connect(fileServerHost);
        client.login(fileFtpUser, fileFtpPass);
        client.changeWorkingDirectory(fileUploadPath);
        client.setBufferSize(1024);
        client.setControlEncoding("UTF-8");
        client.setFileType(FTPClient.BINARY_FILE_TYPE);
        client.enterLocalPassiveMode();
        InputStream inputStream = userIcon.getInputStream();
        client.storeFile(uploadedFileName, inputStream);
        File file = new File(fileUploadPath);
        if (!file.exists()) {
            file.setWritable(true);
            file.mkdirs();
        }
        File targetFile = new File(fileUploadPath, uploadedFileName);
        client.disconnect();
        String userIconAddress = "http://" + fileServerHost + ":" + fileServerPort + "/" + targetFile.getName();
        return Response.successResponse(userIconAddress);
    }


    public Response<String> userRegister(Integer userRegisterType, @RequestBody UserPojo userPojo, String userIconAddress) {
        QueryWrapper queryWrapper = new QueryWrapper();
        switch (userRegisterType) {
            case BusinessCode.userRegisterType.USER_EMAIL_REGISTER:
                // 用户邮箱注册
                queryWrapper.eq("email", userPojo.getEmail());
                UserPojo userEmail = userMapperDao.selectOne(queryWrapper);
                if (null != userEmail) {
                    return Response.errorResponse("邮箱已存在，请更换后尝试");
                }
                userPojo.setUserIcon(userIconAddress);
                int resultCountEmail = userMapperDao.insert(userPojo);
                if (resultCountEmail > 0) {
                    return Response.successResponse("用户注册成功");
                }
                return Response.errorResponse("系统错误，用户注册失败，请联系系统管理员");
            case BusinessCode.userRegisterType.USER_NAME_REGISTER:
                // 用户名注册
                queryWrapper.eq("username", userPojo.getUsername());
                UserPojo username = userMapperDao.selectOne(queryWrapper);
                if (null != username) {
                    return Response.errorResponse("用户名已存在，请更换后尝试");
                }
                userPojo.setUserIcon(userIconAddress);
                int resultCountUsername = userMapperDao.insert(userPojo);
                if (resultCountUsername > 0) {
                    return Response.successResponse("用户注册成功");
                }
                return Response.errorResponse("系统错误，用户注册失败，请联系系统管理员");
            case BusinessCode.userRegisterType.USER_PHONE_REGISTER:
                // 用户手机注册
                queryWrapper.eq("phone", userPojo.getPhone());
                UserPojo phone = userMapperDao.selectOne(queryWrapper);
                if (null != phone) {
                    return Response.errorResponse("手机已存在，请更换后尝试");
                }
                userPojo.setUserIcon(userIconAddress);
                int resultCountPhone = userMapperDao.insert(userPojo);
                if (resultCountPhone > 0) {
                    return Response.successResponse("用户注册成功");
                }
                return Response.errorResponse("系统错误，用户注册失败，请联系系统管理员");
            default:
                break;
        }
        return Response.errorResponse("传入的注册参数不合法，请重新注册");
    }

    public Response<String> resetPassword(HttpSession session, String newPass){
        UserPojo userPojo = (UserPojo) session.getAttribute(BusinessCode.CURRENT_USER);
        if (null == userPojo) {
            return Response.errorResponse("用户未登录，无法修改密码");
        }
        QueryWrapper queryWrapper = new QueryWrapper();
        queryWrapper.eq("username", userPojo.getUsername());
        UserPojo currUser = userMapperDao.selectOne(queryWrapper);
        if (null == currUser) {
            return Response.errorResponse("当前操作非法，禁止操作");
        }
        Map<String, Object> passCheckMap = new HashMap<>();
        passCheckMap.put("username", userPojo.getUsername());
        passCheckMap.put("password", MD5Util.getMD5(userPojo.getPassword()));
        queryWrapper.allEq(passCheckMap);
        UserPojo userPass = userMapperDao.selectOne(queryWrapper);
        if (null == userPass) {
            return Response.errorResponse("旧密码错误，请重新输入");
        }
        userPojo.setPassword(MD5Util.getMD5(newPass));
        int resultCount = userMapperDao.updateById(userPojo);
        if (resultCount > 0){
            return Response.successResponse("密码修改成功");
        }
        return Response.errorResponse("系统错误，密码修改失败，请联系系统管理员");
    }

    public Response<String> forgetResetPassword(HttpSession session, String question, String answer) {
        UserPojo userPojo = (UserPojo) session.getAttribute(BusinessCode.CURRENT_USER);
        if (null == userPojo) {
            return Response.errorResponse("用户未登录，无法修改密码");
        }
        QueryWrapper queryWrapper = new QueryWrapper();
        queryWrapper.eq("pass_question", question);
        int questionCount = userMapperDao.selectCount(queryWrapper);
        if (questionCount == 0){
            return Response.errorResponse("该问题不存在");
        }
        Map<String, Object> checkMap = new HashMap<>();
        checkMap.put("username", userPojo.getUsername());
        checkMap.put("pass_question", question);
        checkMap.put("pass_answer", answer);
        queryWrapper.allEq(checkMap);
        int checkCount = userMapperDao.selectCount(queryWrapper);
        if (checkCount == 0) {
            return Response.errorResponse("问题的答案错误，请重新输入");
        }
        userPojo.setPassword(MD5Util.getMD5(answer));
        int resultCount = userMapperDao.updateById(userPojo);
        if (resultCount > 0) {
            return Response.successResponse("找回密码成功");
        }
        return Response.errorResponse("系统错误，找回密码失败");
    }

    public Response<String> updateUserInfo(HttpSession session, @RequestBody UserPojo userUpdate) {
        UserPojo userPojo = (UserPojo) session.getAttribute(BusinessCode.CURRENT_USER);
        if (null == userPojo) {
            return Response.errorResponse("用户未登录，无法修改个人信息");
        }
        int resultCount = userMapperDao.updateById(userUpdate);
        if (resultCount > 0) {
            return Response.successResponse("修改个人信息成功");
        }
        return Response.errorResponse("系统错误，修改个人信息失败，请联系系统管理员");
    }

}
